package program2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

/**
 * @author Khbindar Arumugam
 * @date 5-19-2019 
 * 
 * @overview 
 * The program gets input from a text file and creates Huffman Code. (The name of the text file should be "input.txt") 
 * This object contains the buildtree, setprefixcodes encode, decode function in order to run the driver class.
 * 
 */

public class HuffmanCode {

		private static Map<Character, String> charPrefixHashMap = new HashMap<>();
		static HuffmanNode root;
	
		private static HuffmanNode buildTree(Map<Character, Integer> freq) {

			PriorityQueue<HuffmanNode> priorityQueue = new PriorityQueue<>();
			
			Set<Character> keySet = freq.keySet();
			
			for (Character c : keySet) {

				HuffmanNode huffmanNode = new HuffmanNode();
				huffmanNode.data = c;
				huffmanNode.frequency = freq.get(c);
				huffmanNode.left = null;
				huffmanNode.right = null;
				priorityQueue.offer(huffmanNode);
			}
			
			
			assert priorityQueue.size() > 0;

			while (priorityQueue.size() > 1) {

				HuffmanNode x = priorityQueue.poll();;
				

				HuffmanNode y = priorityQueue.poll();

				HuffmanNode sum = new HuffmanNode();

				sum.frequency = x.frequency + y.frequency;
				sum.data = '-';

				sum.left = x;

				sum.right = y;
				
				priorityQueue.offer(sum);
			}


			
			return priorityQueue.poll();
		}


		private static void setPrefixCodes(HuffmanNode node, StringBuilder prefix) {
			
			
			if (node != null) {
				if (node.left == null && node.right == null) {
					charPrefixHashMap.put(node.data, prefix.toString());

				} else{
					prefix.append('0');
					setPrefixCodes(node.left, prefix);
					prefix.deleteCharAt(prefix.length() - 1);
					
					
					if(node.right != null) {
					prefix.append('1');
					setPrefixCodes(node.right, prefix);
					prefix.deleteCharAt(prefix.length() - 1);	
					
					}
				}	
			}
		}
		

		static String encode(String line) {
			Map<Character, Integer> freq = new HashMap<>();
			for (int i = 0; i < line.length(); i++) {
				if (!freq.containsKey(line.charAt(i))) {
					freq.put(line.charAt(i), 0);
				}
				freq.put(line.charAt(i), freq.get(line.charAt(i)) + 1);
			}

			System.out.println("Frequency Table = " + freq);
			System.out.println();
			root = buildTree(freq);
			

			setPrefixCodes(root, new StringBuilder());
			System.out.println("Code Table = " + charPrefixHashMap);
			System.out.println();
			
			StringBuilder s = new StringBuilder();

			for (int i = 0; i < line.length(); i++) {
				char c = line.charAt(i);
				s.append(charPrefixHashMap.get(c));
			}

			return s.toString();
		}
		

		static void decode(String line) throws IOException {
			BufferedWriter writer = new BufferedWriter(new FileWriter("src//program2//output.txt"));
			StringBuilder stringBuilder = new StringBuilder();

			HuffmanNode temp = root;

			System.out.println("Encoded message: " + line);
			

			for (int i = 0; i < line.length(); i++) {
				int j = Integer.parseInt(String.valueOf(line.charAt(i)));

				if (j == 0) {
					temp = temp.left;
					if (temp.left == null && temp.right == null) {
						stringBuilder.append(temp.data);
						temp = root;
					}
				}
				if (j == 1) {
					temp = temp.right;
					if (temp.left == null && temp.right == null) {
						stringBuilder.append(temp.data);
						temp = root;
					}
				}
			}
			writer.write(stringBuilder.toString());
		    writer.close();

		}
		
}


	class HuffmanNode implements Comparable<HuffmanNode> {
		Integer frequency;
		char data;
		HuffmanNode left, right;

		public int compareTo(HuffmanNode node) {
			return this.frequency.compareTo(node.frequency);
		}
	}	


