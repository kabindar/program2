package program2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author Khbindar Arumugam
 * @date 5-27-2019 
 * 
 * @overview 
 * The program gets input from a text file and creates Huffman Code. (The name of the text file should be "input.txt") 
 * 
 * @how-to-use-the-program
 * 1.Make sure the input.txt file contains the sentence that you want to process.
 * 2.Run the program
 *
 *@what-it-does
 *1.Program prints the input file message (makes all letters to lowercase while reading it)
 *2.Prints the frequency table for the message
 *3.Creates a Huffman tree (In the background)
 *3.Prints the code table using the Huffman tree
 *4.Prints the encoded message in binary
 *5.Decodes the message from binary to original message and writes it to a new file called output.
 */

public class HuffmanCodeDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
        String line = ""; 
		
		try 
		{
			@SuppressWarnings("resource")
			BufferedReader input = new BufferedReader(new FileReader("src//program2//input.txt"));
			line = input.readLine().toLowerCase();
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		
  
		
		System.out.println("Original message = "+ line); 
		System.out.println();
		String sentence = HuffmanCode.encode(line);
		HuffmanCode.decode(sentence);

	}

}
